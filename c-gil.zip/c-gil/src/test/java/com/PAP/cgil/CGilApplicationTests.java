package com.PAP.cgil;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CGilApplicationTests {

	@Test
	void contextLoads() {
	}

}
